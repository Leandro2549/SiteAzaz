



<?php

//require 'C:\Users\aluno\Documents\Site_avaliacao_AZAZ\PhpSpreadsheet\vendor\autoload.php'; // Importa a biblioteca

//use PhpOffice\PhpSpreadsheet\IOFactory;
//use PhpOffice\PhpSpreadsheet\Spreadsheet;
//use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

//if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recupera os dados do formulário
  //  $avaliacao = $_POST['avaliacao'];
    //$comentario = $_POST['comentario'];

    // Caminho para o arquivo Excel
    //$bancoDados = 'C:\Users\aluno\Documents\Site_avaliacao_AZAZ\bancoDados.xlsx';

    // Carrega o arquivo Excel existente ou cria um novo
    //$spreadsheet = file_exists($bancoDados)
      //  ? IOFactory::load($bancoDados)
        //: new Spreadsheet();

    // Seleciona a planilha "Planilha1"
   // $planilha = $spreadsheet->getSheetByName('avaliacao');

    // Verifica a última linha preenchida
    //$ultimaLinha = $planilha->getHighestRow() + 1;

    // Insere os dados nas colunas A  e B 
    //$planilha->setCellValue("A{$ultimaLinha}", $avaliacao);
    //$planilha->setCellValue("B{$ultimaLinha}", $comentario);

    // Salva o arquivo Excel
    //$writer = new Xlsx($spreadsheet);
   // $writer->save($bancoDados);

    echo 'Dados inseridos com sucesso!';
}
else{
    echo 'Os dados nao foram enviados!';
}
?>